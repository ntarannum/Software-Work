public class Lab1 {

  String f () {
    return "hello world";
  }
  

  int sum(int x, int y) {
    return x+y;
  }

  boolean fizz(int x, int y) {
	int answer = x/y;
	  if(answer == 0)
	  {
		return true;
	  }
	  else return false;
  }

  int cop(int x, int y) {
    return -1;
  }

}
